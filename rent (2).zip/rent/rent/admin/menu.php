<ol class='list-group'>
             <a href="./admin.php"> <li class='list-group-item'>DASHBOARD</li></a>
             <a href="./categories.php"> <li class='list-group-item'>ADD CATEGORIES</li></a>
             <a href="./add-house.php"> <li class='list-group-item'>ADD HOUSES </li></a>
 
             <a href="./users.php"> <li class='list-group-item'>USERS</li></a>
             <a href="./report.php"> <li class='list-group-item'>REPORTS</li></a>
  
           </ol>