<div class="col-md-3"> 

<img src="assets/logo3.png" alt="" class='image'>
</div>

       
   
    <div class="col-md-6">
<center><h3>WELCOME ADMIN DASHBOARD</h3></center> 

</div>

<div class="col-md-3">
<center><a href="logout.php"><button class='btn btn-primary'> LOGOUT</button> </a></center> 
   </div>