<ol class='list-group'>
             <a href="./index.php"> <li class='list-group-item'>DASHBOARD</li></a>
             <a href="./rent.php"> <li class='list-group-item'>RENT HOUSE</li></a>
             <a href="./report.php"> <li class='list-group-item'>REPORTS</li></a>
             <a href="./change.php"> <li class='list-group-item'>CHANGE PASSWORD</li></a>
         
              <!-- <li class='list-group-item'>dashboard</li>
              <li class='list-group-item'>dashboard</li> -->
           </ol>